﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Welcome : Form
    {
        public Welcome()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            StudentLogin s1 = new StudentLogin();
            s1.Show();
        }

        private void loginAdmin_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminLogin a1 = new AdminLogin();
            a1.Show();

        }
    }
}
